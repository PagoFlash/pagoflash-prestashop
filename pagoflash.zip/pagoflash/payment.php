<?php
/**
 * @deprecated 1.5.0 This file is deprecated, use moduleFrontController instead
 */

$useSSL = true;

require('../../config/config.inc.php');
Tools::displayFileAsDeprecated();

$controller = new FrontController();
$controller->init();

Tools::redirect(Context::getContext()->link->getModuleLink('pagoflash', 'payment'));