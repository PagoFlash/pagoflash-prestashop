<?php

// se está tratando de acceder al archivo directamente
if (false == defined('_PS_VERSION_'))
{
  exit;
}

/**
 * Objeto principal que encierra la lógica para realizar el pago mediante la
 * plataforma de PagoFlash
 * 
 * @author Enebrus Kem Lem, C.A.
 * @copyright (c) 2014, Enebrus Kem Lem, C.A.
 * @link http://www.enebruskemlem.com.ve Sitio web de la empresa
 * @version 1.0-1
 */
class PagoFlash extends PaymentModuleCore
{

  /**
   * @var string
   */
  private $_html = '';

  /**
   * @var string
   */
  private $_key_token;

  /**
   * @var string
   */
  private $_key_secret;

  /**
   * @var array
   */
  private $_errores = array();

  public function __construct()
  {
    // nombre identificador del módulo
    $this->name = 'pagoflash';

    // grupo dentro del cual se mostrará el módulo en el panel administrativo
    $this->tab = 'payments_gateways';

    // versión del módulo
    $this->version = '1.0';

    // autor del módulo
    $this->author = 'Enebrus Kem Lem, C.A.';

    // establece que se pueden seleccionar los sistemas monetarios con los cuales trabaja el módulo
    $this->сurrenсies = true;
    $this->currencies_mode = 'checkbox';

    // obtiene los datos de configuración del módulo
    $v_configuracion = Configuration::getMultiple(array('PAGOFLASH_KEY_TOKEN', 'PAGOFLASH_KEY_SECRET'));
    
    // ficha de autenticación recibida al momento de contratar el servicio
    if (isset($v_configuracion['PAGOFLASH_KEY_TOKEN']))
    {
      $this->_key_token = $v_configuracion['PAGOFLASH_KEY_TOKEN'];
    }

    // clave de autenticación recibida al momento de contratar el servicio
    if (isset($v_configuracion['PAGOFLASH_KEY_SECRET']))
    {
      $this->_key_secret = $v_configuracion['PAGOFLASH_KEY_SECRET'];
    }

    parent::__construct();

    // texto a mostrar en el panel administrativo
    $this->displayName = $this->l('PagoFlash');

    // descripción a mostrar en el panel administrativo
    $this->description = $this->l('Pay fast and easy using PagoFlash');

    // mensaje de confirmación que se mostrará cuando se quiera desinstalar el módulo
    $this->confirmUninstall = $this->l('Are you sure that you want to uninstall this module?');

    // no se han indicado los sistemas monetarios a utilizar
    if (0 == count(Currency::checkPaymentCurrencies($this->id)))
    {
      $this->warning = $this->l('There is not selected currency');
    }
  }

  public function install()
  {
    if ((false == parent::install()) || (false == $this->registerHook('payment')) || (false == $this->registerHook('paymentReturn')))
    {
      return false;
    }

    return true;
  }

  public function uninstall()
  {
    if ((false == Configuration::deleteByName('PAGOFLASH_KEY_TOKEN')) || (false == Configuration::deleteByName('PAGOFLASH_KEY_SECRET')) || (false == parent::uninstall()))
    {
      return false;
    }

    return true;
  }

  /**
   * Función que es llamada para mostrar el método de pago como una opción a
   * utilizar por el cliente al momento de confirmar la compra
   * 
   * @param array $p_parametros
   * 
   * @return string
   */
  public function hookPayment($p_parametros)
  {
    // el módulo no está activo
    if (false == $this->active)
    {
      return;
    }

    // el módulo no aplica para el sistema monetario utilizado
    if (false == $this->validarSistemaMonetario($p_parametros['cart']))
    {
      return;
    }

    // establece las variables a utilizar dentro de las vistas
    $this->smarty->assign(array(
      'this_path' => $this->_path,
      'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name . '/'
    ));

    return $this->display(__FILE__, 'payment.tpl');
  }

  /**
   * Función que es llamada cuando el cliente ha seleccionado esté método como
   * el método de pago a utilizar
   * 
   * @param array $p_parametros
   * 
   * @return string
   */
  public function hookPaymentReturn($p_parametros)
  {
    // el módulo no está activo
    if (false == $this->active)
    {
      return;
    }

    // obtiene el estado actual de la orden
    $v_estado = $p_parametros['objOrder']->getCurrentState();

    // el pago fué aceptado
    if (Configuration::get('PS_OS_PAYMENT') == $v_estado)
    {
      // establece las variables a utilizar en la plantilla
      $this->smarty->assign(array(
        'total_to_pay' => Tools::displayPrice($p_parametros['total_to_pay'], $p_parametros['currencyObj'], false),
        'status' => 'ok',
        'id_order' => $p_parametros['objOrder']->id
      ));
    }
    // el pago no fué aceptado
    else
    {
      // establece el estado como fallido
      $this->smarty->assign('status', 'failed');
    }
    
    $this->smarty->assign('this_path', $this->getPathUri());
    
    // muestra la plantilla con el resultado
    return $this->display(__FILE__, 'payment_return.tpl');
  }

  /**
   * Indica si el sistema monetario utilizado para el pago es aceptado por el
   * módulo
   * 
   * @param CartCore $p_carro Datos del carro de compra
   * 
   * @return boolean
   */
  public function validarSistemaMonetario($p_carro)
  {
    // crea una instancia del objeto que representa el sistema monetario utilizado
    $v_sistema_monetario = new Currency($p_carro->id_currency);

    // obtiene los sistemas monetarios permitidos por el módulo
    $v_sistemas_monetarios_modulo = $this->getCurrency($p_carro->id_currency);

    // existen sistemas monetarios
    if (is_array($v_sistemas_monetarios_modulo))
    {
      // recorre los sistemas monetarios obtenidos
      foreach ($v_sistemas_monetarios_modulo as $v_sistema_monetario_modulo)
      {
        // el sistema monetario utilizado está dentro de los sistemas monetarios permitidos por el módulo
        if ($v_sistema_monetario->id == $v_sistema_monetario_modulo['id_currency'])
        {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Muestra la cabecera del método de pago
   */
  private function _displayPagoFlash()
  {
    $this->_html .= <<<HTML
<img src="../modules/pagoflash/pagoflash.png" style="float:left; margin-right:15px;" width="319" height="80" />
<b>{$this->l('This module allow you to pay using PagoFlash International service')}</b>
<br/><br/>
{$this->l('If the client chooses to pay by PagoFlash, the order\'s status will change automatically according to platform answer')}
<div style="clear:both">&nbsp;</div>
HTML;
  }
  
  /**
   * Muestra el formulario de configuración del módulo
   */
  private function _displayForm()
  {
    $v_link = new LinkCore();
    
    $v_opciones = array(
      'action' => Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']),
      'key_token' => htmlentities(Tools::getValue('pf_token', $this->_key_token), ENT_COMPAT, 'UTF-8'),
      'key_secret' => htmlentities(Tools::getValue('pf_secret', $this->_key_secret), ENT_COMPAT, 'UTF-8'),
      'pos_url' => htmlentities($v_link->getModuleLink('pagoflash', 'validation', array(), true), ENT_COMPAT, 'UTF-8')
    );

    $this->_html .= <<<HTML
<form action="{$v_opciones['action']}" method="post">
<fieldset>
  <legend><img src="../img/admin/contact.gif" />{$this->l('PagoFlash account detail')}</legend>
  <table border="0" width="500" cellpadding="0" cellspacing="0" id="form">
    <tr>
      <td width="130" style="vertical-align: top;">{$this->l('Key token')}</td>
      <td style="padding-bottom:15px;">
        <input type="text" name="pf_token" value="{$v_opciones['key_token']}" style="width: 300px;" />
        <p>{$this->l('Key token received when registered in PagoFlash')}</p>
      </td>
    </tr>
    <tr>
      <td width="130" style="vertical-align: top;">{$this->l('Key secret')}</td>
      <td style="padding-bottom:15px;">
        <input type="text" name="pf_secret" value="{$v_opciones['key_secret']}" style="width: 300px;" />
        <p>{$this->l('Key secret received when registered in PagoFlash')}</p>
      </td>
    </tr>
    <tr>
      <td width="130" style="vertical-align: top;">{$this->l('POS URL')}</td>
      <td style="padding-bottom:15px;">
        <p><b>{$v_opciones['pos_url']}</b></p>
        <p>{$this->l('Callback URL of your virtual point of sale')}</p>
      </td>
    </tr>
    <tr>
      <td colspan="2" align="center">
        <input class="button" name="btnSubmit" value="{$this->l('Update settings')}" type="submit" />
      </td>
    </tr>
  </table>
</fieldset>
</form>
HTML;
  }
  
  /**
   * Valida los datos del formulario de configuración
   */
  private function _postValidation()
  {
    // se confirmó el envío del formulario
    if (Tools::isSubmit('btnSubmit'))
    {
      // no se indicó la ficha de seguridad
      if (false == Tools::getValue('pf_token'))
      {
        $this->_errores[] = $this->l('Key token is required.');
      }
      
      // no se indicó la clave de seguridad
      if (false == Tools::getValue('pf_secret'))
      {
        $this->_errores[] = $this->l('Key secret is required.');
      }
    }
  }

  private function _postProcess()
  {
    // se confirmó el envío del formulario
    if (Tools::isSubmit('btnSubmit'))
    {
      Configuration::updateValue('PAGOFLASH_KEY_TOKEN', Tools::getValue('pf_token'));
      Configuration::updateValue('PAGOFLASH_KEY_SECRET', Tools::getValue('pf_secret'));
    }

    $this->_html .= '<div class="conf confirm"> ' . $this->l('Settings updated') . '</div>';
  }

  public function getContent()
  {
    $this->_html = "<h2>{$this->displayName}</h2>";

    // la llamada viene luego de confirmar el formulario de configuración
    if (Tools::isSubmit('btnSubmit'))
    {
      // realiza las validaciones correspondientes
      $this->_postValidation();

      // no hubo errores
      if (0 == count($this->_errores))
      {
        // procesa los datos del formulario
        $this->_postProcess();
      }
      // hubo errores
      else
      {
        // recorre los errores obtenidos
        foreach ($this->_errores as $v_error)
        {
          // agrega el error a la salida
          $this->_html .= '<div class="alert error">' . $v_error . '</div>';
        }
      }
    }
    // la llamada es para visualizar el formulario de configuración
    else
    {
      $this->_html .= '<br />';
    }

    // muestra el formulario de configuración
    $this->_displayPagoFlash();
    $this->_displayForm();

    return $this->_html;
  }

}
