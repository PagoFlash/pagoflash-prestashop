<?php

require_once dirname(__FILE__).'/../../pagoflash.api.client.php';

/**
 * Controlador para el método de pago
 * 
 * @author Enebrus Kem Lem, C.A.
 * @copyright (c) 2014, Enebrus Kem Lem, C.A.
 * @link http://www.enebruskemlem.com.ve Sitio web de la empresa
 * @version 1.0-1
 */
class PagoFlashPaymentModuleFrontController extends ModuleFrontControllerCore
{
	public $ssl = true;
  
	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
    // establece que no se mostrarán los páneles laterales
		$this->display_column_left = false;
    $this->display_column_right = false;
    
		parent::initContent();

    // obtiene los datos del carro de compra
    /* @var $v_carro CartCore */
		$v_carro = $this->context->cart;
    
    // el sistema monetario utilizado no es aceptado por el módulo
		if (false == $this->module->validarSistemaMonetario($v_carro))
    {
			Tools::redirect('index.php?controller=order');
    }
    
    $v_link = new LinkCore();
    
    // instancia la clase que hace uso de la API de PagoFlash
    $v_pagoflash = new apiPagoflash(
      ConfigurationCore::get('PAGOFLASH_KEY_TOKEN'),
      ConfigurationCore::get('PAGOFLASH_KEY_SECRET'),
      urlencode($v_link->getModuleLink('pagoflash', 'validation', array(), true))
    );
    
    // coloca los datos de la cabecera de la llamada
    $v_cabecera = array(
      'pc_order_number' => $v_carro->id,
      'pc_amount' => $v_carro->getOrderTotal(true, Cart::BOTH)
    );
    
    // inicializa el contenedor de los datos de los productos
    $v_datos_productos = array();
    
    // obtiene los productos del carro de compras
    $v_productos_compra = $v_carro->getProducts();
    
    // recorre cada producto para colocar sus datos en el contenedor
    foreach($v_productos_compra as $v_producto)
    {
      // instancia la referencia a la imagen del producto
      $v_imagen_producto = new ImageCore($v_producto['pai_id_image']);
      $v_url_imagen_producto = _PS_BASE_URL_._THEME_PROD_DIR_.$v_imagen_producto->getExistingImgPath().".jpg";
      
      // obtiene la descripción del producto
      $v_descripcion = substr($v_producto['description_short'], 0, 230);

      $v_datos_productos[] = array(
        'pr_name' => substr($v_producto['name'], 0, 127),
        'pr_desc' => (strlen($v_descripcion) > 0)? $v_descripcion:' ',
        'pr_price' => $v_producto['total_wt'],
        'pr_qty' => $v_producto['quantity'],
        'pr_img' => $v_url_imagen_producto
      );
    }

    // hace la llamada a la plataforma mediante el API
    $v_respuesta = $v_pagoflash->procesarPago(
      array(
        'cabecera_de_compra' => $v_cabecera,
        'productos_items' => $v_datos_productos
      ),
      $_SERVER['HTTP_USER_AGENT']
    );
    
    // elimina las advertencias de la respuesta en caso que existan
    $v_respuesta = substr($v_respuesta, strpos($v_respuesta, '{'));
    
    // convierte la respuesta recibida al formato JSON para evaluarla
    $v_respuesta_json = json_decode($v_respuesta);
    
    // la autenticación fué satisfactoria
    if($v_respuesta_json->success != '0')
    {
      ToolsCore::redirect($v_respuesta_json->url_to_buy);
    }
    
    // establece los datos a enviar a la plantilla
    $this->context->smarty->assign(array(
			'nbProducts' => $v_carro->nbProducts(),
			'cust_currency' => $v_carro->id_currency,
			'currencies' => $this->module->getCurrency((int)$v_carro->id_currency),
			'total' => $v_carro->getOrderTotal(true, Cart::BOTH),
      'pf_error' => $v_respuesta_json->error,
			'this_path' => $this->module->getPathUri(),
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/'
		));
    
    // establece la plantilla a mostrar
    $this->setTemplate('payment_execution_error.tpl');
	}
}
