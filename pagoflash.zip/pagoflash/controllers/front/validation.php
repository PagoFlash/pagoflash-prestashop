<?php

require_once dirname(__FILE__).'/../../pagoflash.api.client.php';

/**
 * Controlador para la validación del método de pago
 * 
 * @author Enebrus Kem Lem, C.A.
 * @copyright (c) 2014, Enebrus Kem Lem, C.A.
 * @link http://www.enebruskemlem.com.ve Sitio web de la empresa
 * @version 1.0-1
 */
class PagoFlashValidationModuleFrontController extends ModuleFrontControllerCore
{
  public $ssl = true;
  
  /**
   * @see FrontController::postProcess()
   */
  public function postProcess()
  {
    $v_ficha_confirmacion = null;

    // no se recibió la ficha de confirmación
    if(false == isset($_GET['tk']) || false == isset($_GET['callback']))
    {
      // envía al usuario a la página de inicio
      Tools::redirect('index.php');
    }
    
    // almacena la ficha de confirmación
    $v_ficha_confirmacion = $_GET['tk'];
    
    $v_link = new LinkCore();
     
    // instancia la clase que hace uso de la API de PagoFlash
    $v_pagoflash = new apiPagoflash(
      ConfigurationCore::get('PAGOFLASH_KEY_TOKEN'),
      ConfigurationCore::get('PAGOFLASH_KEY_SECRET'),
      urlencode($v_link->getModuleLink('pagoflash', 'validation', array(), true))
    );

    // valida la ficha de confirmación para garantizar que el pago fué aceptado
    $v_respuesta = $v_pagoflash->validarTokenDeTransaccion($v_ficha_confirmacion, $_SERVER['HTTP_USER_AGENT']);
    
    // elimina las advertencias de la respuesta en caso que existan
    $v_respuesta = substr($v_respuesta, strpos($v_respuesta, '{'));

    // convierte la respuesta al formato JSON
    $v_respuesta_json = json_decode($v_respuesta);

    // la ficha de confirmación no es válida
    if($v_respuesta_json->cod != '1' && $v_respuesta_json->cod != '3')
    {
      // envía al usuario a la página de inicio
      Tools::redirect('index.php');
    }

    // obtiene los datos del carro de compra
    $v_carro = new Cart($v_respuesta_json->order_number);
        
    // no se tiene un carro de compras
    // no se tiene una dirección de envío
    // no se tiene una dirección de facturación
    // el módulo no está activo
    if ((0 == $v_carro->id_customer)
      || (0 == $v_carro->id_address_delivery)
      || (0 == $v_carro->id_address_invoice)
      || (false == $this->module->active))
    {
      Tools::redirect('index.php?controller=order&step=1');
    }
    // obtiene los datos del cliente
    $v_cliente = new Customer($v_carro->id_customer);

    if($v_respuesta_json->cod == '1')
    {
        // se indica que el pago no ha sido autorizado
        $v_autorizada = false;
        
        // verifica que el método de pago todavía esté disponible
        foreach (self::getPaymentModules() as $v_modulo)
        {
          // se está en el módulo actual
          if ($v_modulo['name'] == 'pagoflash')
          {
            $v_autorizada = true;
            break;
          }
        }
        
        // el método de pago no está disponible
        if (false == $v_autorizada)
        {
          die($this->module->l('This payment method is unavailable.', 'validation'));
        }
        
        // el cliente no es válido
        if (false == Validate::isLoadedObject($v_cliente))
        {
          Tools::redirect('index.php?controller=order&step=1');
        }

        // obtiene el sistema monetario utilizado
        #$v_sistema_monetario = $this->context->currency;
        $v_sistema_monetario =  new Customer($v_carro->id_currency);
        
        // obtiene el total de la compra
        $v_total = (float)$v_carro->getOrderTotal(true, Cart::BOTH);

        //valida la compra y cambia el status del pedido
        $this->module->validateOrder(
          $v_carro->id,
          Configuration::get('PS_OS_PAYMENT'),
          $v_total,
          $this->module->displayName,
          NULL,
          array(),
          (int)$v_sistema_monetario->id,
          false,
          $v_cliente->secure_key
        );
    }

    //Obtiene la orden
    $v_order = new Order(Order::getOrderByCartId($v_carro->id));

    Tools::redirect('index.php?controller=order-confirmation&id_cart='.$v_carro->id.'&id_module='.$this->module->id.'&id_order='.$v_order->id.'&key='.$v_cliente->secure_key);
  }

  public static function getPaymentModules()
  {
      $hook_payment = 'Payment';
      if (Db::getInstance()->getValue('SELECT `id_hook` FROM `'._DB_PREFIX_.'hook` WHERE `name` = \'displayPayment\'')) {
          $hook_payment = 'displayPayment';
      }
      
      $query = 'SELECT DISTINCT m.`id_module`, h.`id_hook`, m.`name`, hm.`position`
      FROM `'._DB_PREFIX_.'module` m
      LEFT JOIN `'._DB_PREFIX_.'hook_module` hm ON hm.`id_module` = m.`id_module`
      LEFT JOIN `'._DB_PREFIX_.'hook` h ON hm.`id_hook` = h.`id_hook`
      WHERE h.`name` = \''.pSQL($hook_payment).'\'
      ORDER BY m.`name` DESC';

      return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($query);
  }
}

