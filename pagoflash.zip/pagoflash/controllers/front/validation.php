<?php

require_once dirname(__FILE__).'/../../pagoflash.api.client.php';

/**
 * Controlador para la validación del método de pago
 * 
 * @author Enebrus Kem Lem, C.A.
 * @copyright (c) 2014, Enebrus Kem Lem, C.A.
 * @link http://www.enebruskemlem.com.ve Sitio web de la empresa
 * @version 1.0-1
 */
class PagoFlashValidationModuleFrontController extends ModuleFrontControllerCore
{
  public $ssl = true;
  
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{
    $v_ficha_confirmacion = null;
    
    // no se recibió la ficha de confirmación
    if(false == isset($_GET['tk']))
    {
      // envía al usuario a la página de inicio
      Tools::redirect('index.php');
    }
    
    // almacena la ficha de confirmación
    $v_ficha_confirmacion = $_GET['tk'];
    
    $v_link = new LinkCore();
     
    // instancia la clase que hace uso de la API de PagoFlash
    $v_pagoflash = new apiPagoflash(
      ConfigurationCore::get('PAGOFLASH_KEY_TOKEN'),
      ConfigurationCore::get('PAGOFLASH_KEY_SECRET'),
      urlencode($v_link->getModuleLink('pagoflash', 'validation', array(), true))
    );

    // valida la ficha de confirmación para garantizar que el pago fué aceptado
    $v_respuesta = $v_pagoflash->validarTokenDeTransaccion($v_ficha_confirmacion, $_SERVER['HTTP_USER_AGENT']);
    
    // elimina las advertencias de la respuesta en caso que existan
    $v_respuesta = substr($v_respuesta, strpos($v_respuesta, '{'));

    // convierte la respuesta al formato JSON
    $v_respuesta_json = json_decode($v_respuesta);
    
    // la ficha de confirmación no es válida
    if($v_respuesta_json->cod != '1')
    {
      // envía al usuario a la página de inicio
      Tools::redirect('index.php');
    }
    
    // obtiene los datos del carro de compra
		$v_carro = $this->context->cart;
    
    // no se tiene un carro de compras
    // no se tiene una dirección de envío
    // no se tiene una dirección de facturación
    // el módulo no está activo
		if ((0 == $v_carro->id_customer)
      || (0 == $v_carro->id_address_delivery)
      || (0 == $v_carro->id_address_invoice)
      || (false == $this->module->active))
    {
			Tools::redirect('index.php?controller=order&step=1');
    }

    // se indica que el pago no ha sido autorizado
		$v_autorizada = false;
    
    // verifica que el método de pago todavía esté disponible
		foreach (Module::getPaymentModules() as $v_modulo)
    {
      // se está en el módulo actual
			if ($v_modulo['name'] == 'pagoflash')
			{
				$v_autorizada = true;
				break;
			}
    }
    
    // el método de pago no está disponible
		if (false == $v_autorizada)
    {
			die($this->module->l('This payment method is unavailable.', 'validation'));
    }

    // obtiene los datos del cliente
		$v_cliente = new Customer($v_carro->id_customer);
    
    // el cliente no es válido
		if (false == Validate::isLoadedObject($v_cliente))
    {
			Tools::redirect('index.php?controller=order&step=1');
    }

    // obtiene el sistema monetario utilizado
		$v_sistema_monetario = $this->context->currency;
    
    // obtiene el total de la compra
		$v_total = (float)$v_carro->getOrderTotal(true, Cart::BOTH);

		$this->module->validateOrder(
      $v_carro->id,
      Configuration::get('PS_OS_PAYMENT'),
      $v_total,
      $this->module->displayName,
      NULL,
      array(),
      (int)$v_sistema_monetario->id,
      false,
      $v_cliente->secure_key
    );
    
    // envia al usuario a la página de confirmación
		Tools::redirect('index.php?controller=order-confirmation&id_cart='.$v_carro->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$v_cliente->secure_key);
	}
}
